<form method="get" action="triangulo.php">
    <label for="l1">Lado 1: </label>
    <input name="l1" type="number">
    <label for="l2">Lado 2: </label>
    <input name="l2" type="number">
    <label for="l3">Lado 3: </label>
    <input name="l3" type="number">
    <input type="submit" value="ENVIAR">
</form>